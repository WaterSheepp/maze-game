﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.LabelHor16 = New System.Windows.Forms.Label()
        Me.LabelHor5 = New System.Windows.Forms.Label()
        Me.LabelHor1 = New System.Windows.Forms.Label()
        Me.LabelHor2 = New System.Windows.Forms.Label()
        Me.LabelHor15 = New System.Windows.Forms.Label()
        Me.LabelHor4 = New System.Windows.Forms.Label()
        Me.LabelHor3 = New System.Windows.Forms.Label()
        Me.LabelHor10 = New System.Windows.Forms.Label()
        Me.LabelHor9 = New System.Windows.Forms.Label()
        Me.LabelHor13 = New System.Windows.Forms.Label()
        Me.LabelHor11 = New System.Windows.Forms.Label()
        Me.LabelHor12 = New System.Windows.Forms.Label()
        Me.LabelHor7 = New System.Windows.Forms.Label()
        Me.LabelHor14 = New System.Windows.Forms.Label()
        Me.LabelHor6 = New System.Windows.Forms.Label()
        Me.LabelHor8 = New System.Windows.Forms.Label()
        Me.LabelVer5 = New System.Windows.Forms.Label()
        Me.LabelVer9 = New System.Windows.Forms.Label()
        Me.LabelVer3 = New System.Windows.Forms.Label()
        Me.LabelVer2 = New System.Windows.Forms.Label()
        Me.LabelVer7 = New System.Windows.Forms.Label()
        Me.LabelVer8 = New System.Windows.Forms.Label()
        Me.LabelVer6 = New System.Windows.Forms.Label()
        Me.LabelVer14 = New System.Windows.Forms.Label()
        Me.LabelVer10 = New System.Windows.Forms.Label()
        Me.LabelVer1 = New System.Windows.Forms.Label()
        Me.LabelVer13 = New System.Windows.Forms.Label()
        Me.LabelVer11 = New System.Windows.Forms.Label()
        Me.LabelVer12 = New System.Windows.Forms.Label()
        Me.LabelHor18 = New System.Windows.Forms.Label()
        Me.LabelHor17 = New System.Windows.Forms.Label()
        Me.LabelVer4 = New System.Windows.Forms.Label()
        Me.txt1 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.PictureBox7 = New System.Windows.Forms.PictureBox()
        Me.noCheck3 = New System.Windows.Forms.PictureBox()
        Me.noCheck2 = New System.Windows.Forms.PictureBox()
        Me.noCheck = New System.Windows.Forms.PictureBox()
        Me.check4 = New System.Windows.Forms.PictureBox()
        Me.check3 = New System.Windows.Forms.PictureBox()
        Me.check2 = New System.Windows.Forms.PictureBox()
        Me.check1 = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox6 = New System.Windows.Forms.PictureBox()
        Me.Label13 = New System.Windows.Forms.Label()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.noCheck3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.noCheck2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.noCheck, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.check4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.check3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.check2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.check1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'LabelHor16
        '
        Me.LabelHor16.BackColor = System.Drawing.Color.Transparent
        Me.LabelHor16.Location = New System.Drawing.Point(450, 283)
        Me.LabelHor16.Name = "LabelHor16"
        Me.LabelHor16.Size = New System.Drawing.Size(229, 36)
        Me.LabelHor16.TabIndex = 0
        '
        'LabelHor5
        '
        Me.LabelHor5.BackColor = System.Drawing.Color.Transparent
        Me.LabelHor5.Location = New System.Drawing.Point(339, 188)
        Me.LabelHor5.Name = "LabelHor5"
        Me.LabelHor5.Size = New System.Drawing.Size(266, 36)
        Me.LabelHor5.TabIndex = 1
        '
        'LabelHor1
        '
        Me.LabelHor1.BackColor = System.Drawing.Color.Transparent
        Me.LabelHor1.Location = New System.Drawing.Point(-4, 0)
        Me.LabelHor1.Name = "LabelHor1"
        Me.LabelHor1.Size = New System.Drawing.Size(953, 36)
        Me.LabelHor1.TabIndex = 2
        '
        'LabelHor2
        '
        Me.LabelHor2.BackColor = System.Drawing.Color.Transparent
        Me.LabelHor2.Location = New System.Drawing.Point(-4, 763)
        Me.LabelHor2.Name = "LabelHor2"
        Me.LabelHor2.Size = New System.Drawing.Size(953, 36)
        Me.LabelHor2.TabIndex = 3
        '
        'LabelHor15
        '
        Me.LabelHor15.BackColor = System.Drawing.Color.Transparent
        Me.LabelHor15.Location = New System.Drawing.Point(229, 382)
        Me.LabelHor15.Name = "LabelHor15"
        Me.LabelHor15.Size = New System.Drawing.Size(376, 36)
        Me.LabelHor15.TabIndex = 4
        '
        'LabelHor4
        '
        Me.LabelHor4.BackColor = System.Drawing.Color.Transparent
        Me.LabelHor4.Location = New System.Drawing.Point(450, 94)
        Me.LabelHor4.Name = "LabelHor4"
        Me.LabelHor4.Size = New System.Drawing.Size(499, 36)
        Me.LabelHor4.TabIndex = 5
        '
        'LabelHor3
        '
        Me.LabelHor3.BackColor = System.Drawing.Color.Transparent
        Me.LabelHor3.Location = New System.Drawing.Point(-4, 94)
        Me.LabelHor3.Name = "LabelHor3"
        Me.LabelHor3.Size = New System.Drawing.Size(268, 36)
        Me.LabelHor3.TabIndex = 6
        '
        'LabelHor10
        '
        Me.LabelHor10.BackColor = System.Drawing.Color.Transparent
        Me.LabelHor10.Location = New System.Drawing.Point(146, 478)
        Me.LabelHor10.Name = "LabelHor10"
        Me.LabelHor10.Size = New System.Drawing.Size(229, 36)
        Me.LabelHor10.TabIndex = 7
        '
        'LabelHor9
        '
        Me.LabelHor9.BackColor = System.Drawing.Color.Transparent
        Me.LabelHor9.Location = New System.Drawing.Point(677, 382)
        Me.LabelHor9.Name = "LabelHor9"
        Me.LabelHor9.Size = New System.Drawing.Size(156, 36)
        Me.LabelHor9.TabIndex = 8
        '
        'LabelHor13
        '
        Me.LabelHor13.BackColor = System.Drawing.Color.Transparent
        Me.LabelHor13.Location = New System.Drawing.Point(229, 574)
        Me.LabelHor13.Name = "LabelHor13"
        Me.LabelHor13.Size = New System.Drawing.Size(229, 36)
        Me.LabelHor13.TabIndex = 9
        '
        'LabelHor11
        '
        Me.LabelHor11.BackColor = System.Drawing.Color.Transparent
        Me.LabelHor11.Location = New System.Drawing.Point(677, 670)
        Me.LabelHor11.Name = "LabelHor11"
        Me.LabelHor11.Size = New System.Drawing.Size(229, 36)
        Me.LabelHor11.TabIndex = 10
        '
        'LabelHor12
        '
        Me.LabelHor12.BackColor = System.Drawing.Color.Transparent
        Me.LabelHor12.Location = New System.Drawing.Point(348, 670)
        Me.LabelHor12.Name = "LabelHor12"
        Me.LabelHor12.Size = New System.Drawing.Size(220, 36)
        Me.LabelHor12.TabIndex = 11
        '
        'LabelHor7
        '
        Me.LabelHor7.BackColor = System.Drawing.Color.Transparent
        Me.LabelHor7.Location = New System.Drawing.Point(-4, 188)
        Me.LabelHor7.Name = "LabelHor7"
        Me.LabelHor7.Size = New System.Drawing.Size(155, 36)
        Me.LabelHor7.TabIndex = 12
        '
        'LabelHor14
        '
        Me.LabelHor14.BackColor = System.Drawing.Color.Transparent
        Me.LabelHor14.Location = New System.Drawing.Point(-4, 574)
        Me.LabelHor14.Name = "LabelHor14"
        Me.LabelHor14.Size = New System.Drawing.Size(155, 36)
        Me.LabelHor14.TabIndex = 13
        '
        'LabelHor6
        '
        Me.LabelHor6.BackColor = System.Drawing.Color.Transparent
        Me.LabelHor6.Location = New System.Drawing.Point(110, 283)
        Me.LabelHor6.Name = "LabelHor6"
        Me.LabelHor6.Size = New System.Drawing.Size(154, 36)
        Me.LabelHor6.TabIndex = 14
        '
        'LabelHor8
        '
        Me.LabelHor8.BackColor = System.Drawing.Color.Transparent
        Me.LabelHor8.Location = New System.Drawing.Point(795, 188)
        Me.LabelHor8.Name = "LabelHor8"
        Me.LabelHor8.Size = New System.Drawing.Size(154, 36)
        Me.LabelHor8.TabIndex = 15
        '
        'LabelVer5
        '
        Me.LabelVer5.BackColor = System.Drawing.Color.Transparent
        Me.LabelVer5.Location = New System.Drawing.Point(902, 224)
        Me.LabelVer5.Name = "LabelVer5"
        Me.LabelVer5.Size = New System.Drawing.Size(47, 539)
        Me.LabelVer5.TabIndex = 16
        '
        'LabelVer9
        '
        Me.LabelVer9.BackColor = System.Drawing.Color.Transparent
        Me.LabelVer9.Location = New System.Drawing.Point(677, 130)
        Me.LabelVer9.Name = "LabelVer9"
        Me.LabelVer9.Size = New System.Drawing.Size(40, 384)
        Me.LabelVer9.TabIndex = 17
        '
        'LabelVer3
        '
        Me.LabelVer3.BackColor = System.Drawing.Color.Transparent
        Me.LabelVer3.Location = New System.Drawing.Point(339, 35)
        Me.LabelVer3.Name = "LabelVer3"
        Me.LabelVer3.Size = New System.Drawing.Size(36, 153)
        Me.LabelVer3.TabIndex = 18
        '
        'LabelVer2
        '
        Me.LabelVer2.BackColor = System.Drawing.Color.Transparent
        Me.LabelVer2.Location = New System.Drawing.Point(228, 130)
        Me.LabelVer2.Name = "LabelVer2"
        Me.LabelVer2.Size = New System.Drawing.Size(36, 153)
        Me.LabelVer2.TabIndex = 19
        '
        'LabelVer7
        '
        Me.LabelVer7.BackColor = System.Drawing.Color.Transparent
        Me.LabelVer7.Location = New System.Drawing.Point(450, 418)
        Me.LabelVer7.Name = "LabelVer7"
        Me.LabelVer7.Size = New System.Drawing.Size(36, 192)
        Me.LabelVer7.TabIndex = 20
        '
        'LabelVer8
        '
        Me.LabelVer8.BackColor = System.Drawing.Color.Transparent
        Me.LabelVer8.Location = New System.Drawing.Point(339, 292)
        Me.LabelVer8.Name = "LabelVer8"
        Me.LabelVer8.Size = New System.Drawing.Size(36, 90)
        Me.LabelVer8.TabIndex = 21
        '
        'LabelVer6
        '
        Me.LabelVer6.BackColor = System.Drawing.Color.Transparent
        Me.LabelVer6.Location = New System.Drawing.Point(569, 478)
        Me.LabelVer6.Name = "LabelVer6"
        Me.LabelVer6.Size = New System.Drawing.Size(36, 221)
        Me.LabelVer6.TabIndex = 22
        '
        'LabelVer14
        '
        Me.LabelVer14.BackColor = System.Drawing.Color.Transparent
        Me.LabelVer14.Location = New System.Drawing.Point(795, 292)
        Me.LabelVer14.Name = "LabelVer14"
        Me.LabelVer14.Size = New System.Drawing.Size(36, 90)
        Me.LabelVer14.TabIndex = 23
        '
        'LabelVer10
        '
        Me.LabelVer10.BackColor = System.Drawing.Color.Transparent
        Me.LabelVer10.Location = New System.Drawing.Point(115, 382)
        Me.LabelVer10.Name = "LabelVer10"
        Me.LabelVer10.Size = New System.Drawing.Size(36, 317)
        Me.LabelVer10.TabIndex = 24
        '
        'LabelVer1
        '
        Me.LabelVer1.BackColor = System.Drawing.Color.Transparent
        Me.LabelVer1.Location = New System.Drawing.Point(-4, 35)
        Me.LabelVer1.Name = "LabelVer1"
        Me.LabelVer1.Size = New System.Drawing.Size(36, 539)
        Me.LabelVer1.TabIndex = 25
        '
        'LabelVer13
        '
        Me.LabelVer13.BackColor = System.Drawing.Color.Transparent
        Me.LabelVer13.Location = New System.Drawing.Point(795, 478)
        Me.LabelVer13.Name = "LabelVer13"
        Me.LabelVer13.Size = New System.Drawing.Size(36, 123)
        Me.LabelVer13.TabIndex = 26
        '
        'LabelVer11
        '
        Me.LabelVer11.BackColor = System.Drawing.Color.Transparent
        Me.LabelVer11.Location = New System.Drawing.Point(228, 670)
        Me.LabelVer11.Name = "LabelVer11"
        Me.LabelVer11.Size = New System.Drawing.Size(36, 93)
        Me.LabelVer11.TabIndex = 27
        '
        'LabelVer12
        '
        Me.LabelVer12.BackColor = System.Drawing.Color.Transparent
        Me.LabelVer12.Location = New System.Drawing.Point(-4, 670)
        Me.LabelVer12.Name = "LabelVer12"
        Me.LabelVer12.Size = New System.Drawing.Size(36, 93)
        Me.LabelVer12.TabIndex = 28
        '
        'LabelHor18
        '
        Me.LabelHor18.BackColor = System.Drawing.Color.Transparent
        Me.LabelHor18.Location = New System.Drawing.Point(602, 574)
        Me.LabelHor18.Name = "LabelHor18"
        Me.LabelHor18.Size = New System.Drawing.Size(107, 27)
        Me.LabelHor18.TabIndex = 29
        '
        'LabelHor17
        '
        Me.LabelHor17.BackColor = System.Drawing.Color.Transparent
        Me.LabelHor17.Location = New System.Drawing.Point(703, 478)
        Me.LabelHor17.Name = "LabelHor17"
        Me.LabelHor17.Size = New System.Drawing.Size(107, 36)
        Me.LabelHor17.TabIndex = 30
        '
        'LabelVer4
        '
        Me.LabelVer4.BackColor = System.Drawing.Color.Transparent
        Me.LabelVer4.Location = New System.Drawing.Point(905, 35)
        Me.LabelVer4.Name = "LabelVer4"
        Me.LabelVer4.Size = New System.Drawing.Size(44, 59)
        Me.LabelVer4.TabIndex = 31
        '
        'txt1
        '
        Me.txt1.AutoSize = True
        Me.txt1.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt1.Location = New System.Drawing.Point(969, 17)
        Me.txt1.Name = "txt1"
        Me.txt1.Size = New System.Drawing.Size(267, 36)
        Me.txt1.TabIndex = 34
        Me.txt1.Text = "WORDS TO FIND"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(975, 85)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(86, 25)
        Me.Label1.TabIndex = 35
        Me.Label1.Text = "Helado"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(970, 160)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(115, 25)
        Me.Label2.TabIndex = 36
        Me.Label2.Text = "Automovil"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(975, 224)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(59, 25)
        Me.Label3.TabIndex = 37
        Me.Label3.Text = "Rico"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(975, 294)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(70, 25)
        Me.Label4.TabIndex = 38
        Me.Label4.Text = "Lindo"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.333333!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(827, 56)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(67, 15)
        Me.Label5.TabIndex = 43
        Me.Label5.Text = "Delicioso"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.333333!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(827, 725)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(48, 15)
        Me.Label6.TabIndex = 44
        Me.Label6.Text = "Bonito"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.333333!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(450, 244)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(42, 15)
        Me.Label7.TabIndex = 45
        Me.Label7.Text = "Carro"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.333333!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(52, 56)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(32, 15)
        Me.Label8.TabIndex = 46
        Me.Label8.Text = "Frio"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.333333!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(52, 524)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(40, 15)
        Me.Label9.TabIndex = 47
        Me.Label9.Text = "Popo"
        '
        'Label10
        '
        Me.Label10.AllowDrop = True
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.333333!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(611, 684)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(60, 15)
        Me.Label10.TabIndex = 48
        Me.Label10.Text = "Caliente"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.333333!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(339, 253)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(31, 15)
        Me.Label11.TabIndex = 49
        Me.Label11.Text = "Feo"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.333333!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(734, 346)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(44, 15)
        Me.Label12.TabIndex = 50
        Me.Label12.Text = "Dulce"
        '
        'PictureBox7
        '
        Me.PictureBox7.Location = New System.Drawing.Point(1034, 697)
        Me.PictureBox7.Name = "PictureBox7"
        Me.PictureBox7.Size = New System.Drawing.Size(125, 89)
        Me.PictureBox7.TabIndex = 55
        Me.PictureBox7.TabStop = False
        '
        'noCheck3
        '
        Me.noCheck3.Image = Global.maze.My.Resources.Resources.nocheck
        Me.noCheck3.Location = New System.Drawing.Point(1175, 383)
        Me.noCheck3.Name = "noCheck3"
        Me.noCheck3.Size = New System.Drawing.Size(39, 35)
        Me.noCheck3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.noCheck3.TabIndex = 53
        Me.noCheck3.TabStop = False
        Me.noCheck3.Visible = False
        '
        'noCheck2
        '
        Me.noCheck2.Image = Global.maze.My.Resources.Resources.nocheck
        Me.noCheck2.Location = New System.Drawing.Point(1075, 383)
        Me.noCheck2.Name = "noCheck2"
        Me.noCheck2.Size = New System.Drawing.Size(39, 35)
        Me.noCheck2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.noCheck2.TabIndex = 52
        Me.noCheck2.TabStop = False
        Me.noCheck2.Visible = False
        '
        'noCheck
        '
        Me.noCheck.Image = Global.maze.My.Resources.Resources.nocheck
        Me.noCheck.Location = New System.Drawing.Point(975, 383)
        Me.noCheck.Name = "noCheck"
        Me.noCheck.Size = New System.Drawing.Size(39, 35)
        Me.noCheck.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.noCheck.TabIndex = 51
        Me.noCheck.TabStop = False
        Me.noCheck.Visible = False
        '
        'check4
        '
        Me.check4.Image = Global.maze.My.Resources.Resources.check
        Me.check4.Location = New System.Drawing.Point(1175, 294)
        Me.check4.Name = "check4"
        Me.check4.Size = New System.Drawing.Size(39, 35)
        Me.check4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.check4.TabIndex = 42
        Me.check4.TabStop = False
        Me.check4.Visible = False
        '
        'check3
        '
        Me.check3.Image = Global.maze.My.Resources.Resources.check
        Me.check3.Location = New System.Drawing.Point(1175, 224)
        Me.check3.Name = "check3"
        Me.check3.Size = New System.Drawing.Size(39, 35)
        Me.check3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.check3.TabIndex = 41
        Me.check3.TabStop = False
        Me.check3.Visible = False
        '
        'check2
        '
        Me.check2.Image = Global.maze.My.Resources.Resources.check
        Me.check2.Location = New System.Drawing.Point(1175, 160)
        Me.check2.Name = "check2"
        Me.check2.Size = New System.Drawing.Size(39, 35)
        Me.check2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.check2.TabIndex = 40
        Me.check2.TabStop = False
        Me.check2.Visible = False
        '
        'check1
        '
        Me.check1.Image = Global.maze.My.Resources.Resources.check
        Me.check1.Location = New System.Drawing.Point(1175, 85)
        Me.check1.Name = "check1"
        Me.check1.Size = New System.Drawing.Size(39, 35)
        Me.check1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.check1.TabIndex = 39
        Me.check1.TabStop = False
        Me.check1.Visible = False
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox1.Image = Global.maze.My.Resources.Resources.stand
        Me.PictureBox1.Location = New System.Drawing.Point(864, 141)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(42, 44)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 32
        Me.PictureBox1.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox2.BackgroundImage = Global.maze.My.Resources.Resources.maze
        Me.PictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox2.Location = New System.Drawing.Point(-1, 0)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(950, 799)
        Me.PictureBox2.TabIndex = 33
        Me.PictureBox2.TabStop = False
        '
        'PictureBox6
        '
        Me.PictureBox6.Image = Global.maze.My.Resources.Resources.poop
        Me.PictureBox6.Location = New System.Drawing.Point(1061, 716)
        Me.PictureBox6.Name = "PictureBox6"
        Me.PictureBox6.Size = New System.Drawing.Size(66, 70)
        Me.PictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox6.TabIndex = 54
        Me.PictureBox6.TabStop = False
        Me.PictureBox6.Visible = False
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.BackColor = System.Drawing.Color.MediumSlateBlue
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 72.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(128, 319)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(714, 122)
        Me.Label13.TabIndex = 56
        Me.Label13.Text = "GAME OVER"
        Me.Label13.Visible = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.CornflowerBlue
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(1248, 798)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.PictureBox7)
        Me.Controls.Add(Me.noCheck3)
        Me.Controls.Add(Me.noCheck2)
        Me.Controls.Add(Me.noCheck)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.check4)
        Me.Controls.Add(Me.check3)
        Me.Controls.Add(Me.check2)
        Me.Controls.Add(Me.check1)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txt1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.LabelVer4)
        Me.Controls.Add(Me.LabelHor17)
        Me.Controls.Add(Me.LabelHor18)
        Me.Controls.Add(Me.LabelVer12)
        Me.Controls.Add(Me.LabelVer11)
        Me.Controls.Add(Me.LabelVer13)
        Me.Controls.Add(Me.LabelVer1)
        Me.Controls.Add(Me.LabelVer10)
        Me.Controls.Add(Me.LabelVer14)
        Me.Controls.Add(Me.LabelVer6)
        Me.Controls.Add(Me.LabelVer8)
        Me.Controls.Add(Me.LabelVer7)
        Me.Controls.Add(Me.LabelVer2)
        Me.Controls.Add(Me.LabelVer3)
        Me.Controls.Add(Me.LabelVer9)
        Me.Controls.Add(Me.LabelVer5)
        Me.Controls.Add(Me.LabelHor8)
        Me.Controls.Add(Me.LabelHor6)
        Me.Controls.Add(Me.LabelHor14)
        Me.Controls.Add(Me.LabelHor7)
        Me.Controls.Add(Me.LabelHor12)
        Me.Controls.Add(Me.LabelHor11)
        Me.Controls.Add(Me.LabelHor13)
        Me.Controls.Add(Me.LabelHor9)
        Me.Controls.Add(Me.LabelHor10)
        Me.Controls.Add(Me.LabelHor3)
        Me.Controls.Add(Me.LabelHor4)
        Me.Controls.Add(Me.LabelHor15)
        Me.Controls.Add(Me.LabelHor2)
        Me.Controls.Add(Me.LabelHor1)
        Me.Controls.Add(Me.LabelHor5)
        Me.Controls.Add(Me.LabelHor16)
        Me.Controls.Add(Me.PictureBox6)
        Me.DoubleBuffered = True
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.noCheck3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.noCheck2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.noCheck, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.check4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.check3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.check2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.check1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents LabelHor16 As Label
    Friend WithEvents LabelHor5 As Label
    Friend WithEvents LabelHor1 As Label
    Friend WithEvents LabelHor2 As Label
    Friend WithEvents LabelHor15 As Label
    Friend WithEvents LabelHor4 As Label
    Friend WithEvents LabelHor3 As Label
    Friend WithEvents LabelHor10 As Label
    Friend WithEvents LabelHor9 As Label
    Friend WithEvents LabelHor13 As Label
    Friend WithEvents LabelHor11 As Label
    Friend WithEvents LabelHor12 As Label
    Friend WithEvents LabelHor7 As Label
    Friend WithEvents LabelHor14 As Label
    Friend WithEvents LabelHor6 As Label
    Friend WithEvents LabelHor8 As Label
    Friend WithEvents LabelVer5 As Label
    Friend WithEvents LabelVer9 As Label
    Friend WithEvents LabelVer3 As Label
    Friend WithEvents LabelVer2 As Label
    Friend WithEvents LabelVer7 As Label
    Friend WithEvents LabelVer8 As Label
    Friend WithEvents LabelVer6 As Label
    Friend WithEvents LabelVer14 As Label
    Friend WithEvents LabelVer10 As Label
    Friend WithEvents LabelVer1 As Label
    Friend WithEvents LabelVer13 As Label
    Friend WithEvents LabelVer11 As Label
    Friend WithEvents LabelVer12 As Label
    Friend WithEvents LabelHor18 As Label
    Friend WithEvents LabelHor17 As Label
    Friend WithEvents LabelVer4 As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents txt1 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents check1 As PictureBox
    Friend WithEvents check2 As PictureBox
    Friend WithEvents check3 As PictureBox
    Friend WithEvents check4 As PictureBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Public WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents noCheck As PictureBox
    Friend WithEvents noCheck2 As PictureBox
    Friend WithEvents noCheck3 As PictureBox
    Friend WithEvents PictureBox6 As PictureBox
    Friend WithEvents PictureBox7 As PictureBox
    Friend WithEvents Label13 As Label
End Class
